package com.example.soccermatchhighlights;

public class Match {
    private String title;
    private String date;
    private String teams;
    private String thumbnailUrl;
    private String videoUrl;

    public Match(String title, String date, String teams, String thumbnailUrl, String videoUrl) {
        this.title = title;
        this.date = date;
        this.teams = teams;
        this.thumbnailUrl = thumbnailUrl;
        this.videoUrl = videoUrl;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public String getTeams() {
        return teams;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public String getVideoUrl() {
        return videoUrl;
    }
}
