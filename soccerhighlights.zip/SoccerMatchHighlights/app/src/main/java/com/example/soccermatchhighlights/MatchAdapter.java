package com.example.soccermatchhighlights;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.List;

public class MatchAdapter extends RecyclerView.Adapter<MatchAdapter.MatchViewHolder> {
    private Context context;
    private List<Match> matchList;

    public MatchAdapter(Context context, List<Match> matchList) {
        this.context = context;
        this.matchList = matchList;
    }

    @NonNull
    @Override
    public MatchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_match, parent, false);
        return new MatchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MatchViewHolder holder, int position) {
        Match match = matchList.get(position);
        holder.textMatchTitle.setText(match.getTitle());
        holder.textMatchDate.setText(match.getDate());
        holder.textTeams.setText(match.getTeams());
        Picasso.get().load(match.getThumbnailUrl()).into(holder.imageThumbnail);
    }

    @Override
    public int getItemCount() {
        return matchList.size();
    }

    public static class MatchViewHolder extends RecyclerView.ViewHolder {
        TextView textMatchTitle, textMatchDate, textTeams;
        ImageView imageThumbnail;

        public MatchViewHolder(@NonNull View itemView) {
            super(itemView);
            textMatchTitle = itemView.findViewById(R.id.text_match_title);
            textMatchDate = itemView.findViewById(R.id.text_match_date);
            textTeams = itemView.findViewById(R.id.text_teams);
            imageThumbnail = itemView.findViewById(R.id.image_thumbnail);
        }
    }
}
