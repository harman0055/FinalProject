package com.example.soccermatchhighlights;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private MatchAdapter matchAdapter;
    private List<Match> matchList;
    private RequestQueue requestQueue;
    private static final String API_URL = "https://www.scorebat.com/video-api/v1/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("Test", "On Create");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        Log.d("Test", "recycle view" + recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        matchList = new ArrayList<>();
        requestQueue = Volley.newRequestQueue(this);
        parseJSON();
    }

    private void parseJSON() {
        Log.d("Test", "parseJSON");
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, API_URL, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            Log.d("Test", "JSON Response: " + response.toString()); // Log the JSON response

                            for (int i = 0; i < response.length(); i++) {
                                JSONObject matchObject = response.getJSONObject(i);
                                String title = matchObject.getString("title");
                                String date = matchObject.getString("date");

                                JSONObject side1Object = matchObject.getJSONObject("side1");
                                JSONObject side2Object = matchObject.getJSONObject("side2");
                                String teams = side1Object.getString("name") + " vs " + side2Object.getString("name");

                                String thumbnailUrl = matchObject.getString("thumbnail");
                                String videoUrl = matchObject.getJSONArray("videos").getJSONObject(0).getString("embed");

                                // Creating Match object and adding it to the list
                                Match match = new Match(title, date, teams, thumbnailUrl, videoUrl);
                                matchList.add(match);
                            }

                            matchAdapter = new MatchAdapter(MainActivity.this, matchList);
                            recyclerView.setAdapter(matchAdapter);
                        } catch (JSONException e) {
                            Log.e("Test", "JSON Parsing Error: " + e.getMessage()); // Log JSON parsing error
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Log.e("Test", "Volley Error: " + error.getMessage()); // Log Volley error
                    }
                });
        requestQueue.add(request);
    }


}
