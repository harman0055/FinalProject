package com.example.soccermatchhighlights;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class MatchDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_match_details);
        Log.d("Test", "Setting up the new layout");

        // Initialize views
        ImageView thumbnail = findViewById(R.id.image_thumbnail);
        TextView title = findViewById(R.id.text_match_title);
        TextView date = findViewById(R.id.text_match_date);
        TextView teams = findViewById(R.id.text_teams);
        WebView webView = findViewById(R.id.web_view_highlights);

        TextView team1TextView = findViewById(R.id.text_teams);
        TextView team2TextView = findViewById(R.id.text_teams);

        Button highlightButton = findViewById(R.id.button_watch_highlights);
        Button competitionButton = findViewById(R.id.button_watch_highlights);


        // Get data from intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String thumbnailUrl = extras.getString("thumbnail");
            String matchTitle = extras.getString("title");
            String matchDate = extras.getString("date");
            String team1 = extras.getString("team1");
            String team2 = extras.getString("team2");
            String competitionName = extras.getString("competitionName");
            String competitionUrl = extras.getString("competitionUrl");
            String team1Url = extras.getString("team1Url");
            String team2Url = extras.getString("team2Url");
            String highlightsEmbed = extras.getString("highlightsEmbed");
            String highlightUrl = extras.getString("highlightUrl");

            // Set data to views
            Glide.with(this).load(thumbnailUrl).into(thumbnail);
            title.setText(matchTitle);
            date.setText(matchDate);
            teams.setText(team1 + " vs " + team2);
            competition.setText(competitionName);
            team1TextView.setText(team1);
            team2TextView.setText(team2);

            highlightButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(highlightUrl));
                    view.getContext().startActivity(intent);
                }
            });

            team1Button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(team1Url));
                    view.getContext().startActivity(intent);
                }
            });

            team2Button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(team2Url));
                    view.getContext().startActivity(intent);
                }
            });

            competitionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(competitionUrl));
                    view.getContext().startActivity(intent);
                }
            });

            // Set WebView to display highlights
            webView.loadData(highlightsEmbed, "text/html", "UTF-8");
        }
    }
}

