package com.example.pexels;

public class Photo {
    private String photographer;
    private String thumbnailUrl;
    private String dimensions;
    private String url;

    public Photo(String photographer, String thumbnailUrl, String dimensions, String url) {
        this.photographer = photographer;
        this.thumbnailUrl = thumbnailUrl;
        this.dimensions = dimensions;
        this.url = url;
    }

    public String getPhotographer() {
        return photographer;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public String getDimensions() {
        return dimensions;
    }

    public String getUrl() {
        return url;
    }
}


