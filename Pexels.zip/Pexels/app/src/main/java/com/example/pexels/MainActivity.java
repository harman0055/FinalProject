package com.example.pexels;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText searchEditText;
    private Button searchButton;
    private RecyclerView photoRecyclerView;
    private PhotoAdapter photoAdapter;
    private List<Photo> photoList;
    private RequestQueue requestQueue;

    private static final String PREFS_NAME = "MyPrefsFile";
    private static final String PREF_SEARCH_TERM = "searchTerm";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);
        photoRecyclerView = findViewById(R.id.photoRecyclerView);

        photoList = new ArrayList<>();
        photoAdapter = new PhotoAdapter(photoList);
        photoRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        photoRecyclerView.setAdapter(photoAdapter);

        requestQueue = Volley.newRequestQueue(this);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedSearchTerm = prefs.getString(PREF_SEARCH_TERM, "");
        searchEditText.setText(savedSearchTerm);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchTerm = searchEditText.getText().toString().trim();
                if (!searchTerm.isEmpty()) {
                    fetchPhotos(searchTerm);
                }
            }
        });
    }

    private void fetchPhotos(String searchTerm) {
        Log.d("Test", "Fetch photo");
        String url = "https://api.pexels.com/v1/search?query=" + searchTerm;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        photoList.clear();
                        try {
                            JSONArray photosArray = response.getJSONArray("photos");
                            for (int i = 0; i < photosArray.length(); i++) {
                                JSONObject photoObject = photosArray.getJSONObject(i);
                                String photographer = photoObject.getString("photographer");
                                String thumbnailUrl = photoObject.getJSONObject("src").getString("medium");
                                int width = photoObject.getInt("width");
                                int height = photoObject.getInt("height");
                                String url = photoObject.getString("url");

                                // Construct the dimensions string
                                String dimensions = "Dimensions: " + width + "x" + height;

                                photoList.add(new Photo(photographer, thumbnailUrl, dimensions, url));
                            }
                            photoAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Test", "Volley Error : " + error.toString());
                error.printStackTrace();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Authorization", "64ISamPqfRjAj4SD5KVH8j7mEMMfuj4JOBS1ZZdV8fGqsLNYfu8cAUvR");
                return headers;
            }
        };

        requestQueue.add(request);
    }
}
